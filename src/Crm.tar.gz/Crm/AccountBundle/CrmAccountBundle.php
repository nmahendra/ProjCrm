<?php

namespace Crm\AccountBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CrmAccountBundle extends Bundle
{
}
